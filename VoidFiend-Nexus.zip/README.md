# VoidFiend Nexus a rework mod 
This mod feature a number of QOL changes to Voidfiend including changes to his vfx beam abilities and his supress ability 
ever got annoyed at the fact corruption takes more hp then it actually gives? well this changes that with settings like efficiency mode
Ever wanted to customize the corrupted beam? well u can do that in this mod. 
Ontop of these changes there is also a overhaul to the skill icon's while in corrupted mode, they now dynamically update based on your state unlike the base game where the tooltips only show default skills. 


# Supress rework

Two Gameplay Modes:

All-or-Nothing Mode: Spends your entire available resource (spendable corruption or a portion of health) for an equal 1:1 reward. High risk, high reward.

Fixed Trade Mode: Spends a fixed, user-defined percentage of your resources (e.g., spend 35% corruption to heal for 35% health).

Efficient Trades: When enabled, the ability will never spend more resources than needed. If you only need 10% health, it will only consume 10% corruption, saving the rest.

Aegis Support: The "Efficient Trades" logic is fully compatible with Aegis, allowing overhealing to be converted into a temporary barrier.

Configurable Charges: Set the maximum number of charges for both the normal and corrupted versions of the ability independently. You can also enable infinite charges for either mode.

Dynamic Tooltips: The in-game ability description automatically updates to show the correct values based on your configuration choices.


# Voidfiend Beam changes 


Customizable Beam Range: Adjust the maximum distance of the corrupted (Lazer) beam via a slider.

Adjustable VFX Size: Change the width, height, and length of the beam's visual effect to make it as thin or thick as you like.

Laser Mode: Enable a special mode for either beam corrupted/regular to remove all spread and bloom, turning your primary fire into a perfectly accurate laser.

VFX Clipping Fix: A small offset is applied to impact effects to prevent them from clipping into the ground or walls.

Added environment Hit VFX to the corrupted lazer as it has none in the base game due to its short range. 


# Vfx changes 


![Pictures of changed vfx](https://imgur.com/HJyXX78.png)

# The glowing Light ball on hit was red now is purple, the light emanating around it on the ground was changed to purple to match the theme of regular void fiend. (The ball near the muzzle is also purple now) 

![Charging of flood vfx changes](https://imgur.com/NPavDn8.png)

# Original color of the eminating light was red not fitting the theme of regular mode so it was changed to a deep purple. 

![Trespass regular mode vfx changes](https://imgur.com/VeJfsiz.png)

# Trespass originally had terrible vfx for its regular mode as the radiating light was red just like many other parts that has been changed to a fitting purple

![Flood regular has a weird impact particle that was red](https://imgur.com/G1JDTY0.png)

# Flood changed to having the red flame particle coming out of it to be purple to match voidfiends base form theme aswell. 

![Corrupted drown changes](https://imgur.com/CqaR4J3.png) 

# Corrupted drown can visibly impact terrain now where as before it did impact it but did not show it 

![Corrupted suppress vfx changes](https://imgur.com/1lgBawt.png)

# Corrupted suppress had a purple glowing light before now its red to match the corrupted theme, regular form's light stays green as it makes thematic sense and matches the skill icon color. 

![Corrupted flood vfx changes](https://imgur.com/9MyzLOG.png)

# Corrupted flood has been changed as the triangle it used to shoot was purple for some reason in the base game now its properly red to match the color of the corrupt state. Also the muzzle flash effect has had its own vfx replaced (the red little spiky semi circles) to be red with some other colors mixed in, as they were also purple for some reason in the base game. 

![Corrupted red ball vfx changes](https://imgur.com/OlweQFd.png)

# The drown red ball projtile now has red little particles coming out of as it flies those tiny particles were normally purple in the base game. 

![Regular flood vfx changes](https://imgur.com/EmeepcG.png)

# Regular drown projectile has had its emitter light changed to be purple to match the theme of the base mode Voidfiend as originally it was red. This change applies to both the small and big projectile.  







# Changelog

0.2.0:

-Merged RiskOfOptions settings tabs to be less chaotic. 

-Fixed bug when leaving to main menu while having corruption buff. The vfx would not switch back to its original purple color in regular Voidfiend non corrupt state, when starting a new run. 

-Changed the color of light that emits from a small vfx ball belonging to regular non-corrupted drown and flood, from red to purple.(It spawns near the muzzle when firing, and it's difficult to see unless you have a high attack speed and fire many in succession) 

0.1.0: 

-Initial release 

